# Receipt Management Web Application

## Setup

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Ensure Tesseract OCR is installed on your system.
   - macOS: `brew install tesseract`
   - Ubuntu: `sudo apt-get install tesseract-ocr`

3. Run the application:
   ```bash
   python -m uvicorn app.main:app --reload
   ```

## API Endpoints

- `POST /upload` - Upload a receipt PDF
- `POST /validate` - Validate uploaded PDF
- `POST /process` - Extract receipt details
- `GET /receipts` - List all receipts
- `GET /receipts/{id}` - Get receipt details

## Project Structure

- `app/` - Application code
- `uploads/` - Uploaded PDF files
- `receipts.db` - SQLite database

## Notes
- Duplicate receipts are updated, not duplicated.
- See code comments for more details.

## Google Gemini Integration
- Create a `.env` file in the project root with:
  ```env
  GOOGLE_API_KEY=your_api_key_here
  ```

## User Dashboard
- Access the dashboard at [http://localhost:8000/](http://localhost:8000/)
- Upload, validate, and process receipts via the web UI. 