from sqlalchemy.orm import Session
from . import models
from datetime import datetime

def get_receipt_file_by_name(db: Session, file_name: str):
    return db.query(models.ReceiptFile).filter(models.ReceiptFile.file_name == file_name).first()

def create_receipt_file(db: Session, file_name: str, file_path: str):
    db_file = models.ReceiptFile(file_name=file_name, file_path=file_path)
    db.add(db_file)
    db.commit()
    db.refresh(db_file)
    return db_file

def update_receipt_file(db: Session, db_file: models.ReceiptFile, **kwargs):
    for key, value in kwargs.items():
        setattr(db_file, key, value)
    db_file.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(db_file)
    return db_file

def delete_receipt_file(db: Session, file_id: int):
    db_file = db.query(models.ReceiptFile).filter(models.ReceiptFile.id == file_id).first()
    if db_file:
        db.delete(db_file)
        db.commit()
        return True
    return False

def get_receipt(db: Session, receipt_id: int):
    return db.query(models.Receipt).filter(models.Receipt.id == receipt_id).first()

def get_receipt_by_file_path(db: Session, file_path: str):
    return db.query(models.Receipt).filter(models.Receipt.file_path == file_path).first()

def update_receipt(db: Session, db_receipt: models.Receipt, **kwargs):
    for key, value in kwargs.items():
        setattr(db_receipt, key, value)
    db_receipt.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(db_receipt)
    return db_receipt

def delete_receipt(db: Session, receipt_id: int):
    db_receipt = db.query(models.Receipt).filter(models.Receipt.id == receipt_id).first()
    if db_receipt:
        db.delete(db_receipt)
        db.commit()
        return True
    return False

def create_receipt(db: Session, **kwargs):
    file_path = kwargs.get('file_path')
    db_receipt = get_receipt_by_file_path(db, file_path)
    if db_receipt:
        return update_receipt(db, db_receipt, **kwargs)
    db_receipt = models.Receipt(**kwargs)
    db.add(db_receipt)
    db.commit()
    db.refresh(db_receipt)
    return db_receipt

def list_receipts(db: Session):
    return db.query(models.Receipt).all()
