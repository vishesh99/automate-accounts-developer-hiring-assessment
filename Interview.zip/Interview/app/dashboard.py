from fastapi import APIRouter, Request, UploadFile, Form, Depends, File
from fastapi.templating import Jinja2Templates
from fastapi.responses import RedirectResponse, StreamingResponse
from sqlalchemy.orm import Session
from .deps import get_db
from . import crud, config, utils, ocr
import os
import time
from datetime import datetime

templates = Jinja2Templates(directory="app/templates")
router = APIRouter()

@router.get("/")
def dashboard(request: Request, db: Session = Depends(get_db), info: str = "", ocr_text: str = ""):
    files = db.query(crud.models.ReceiptFile).all()
    receipts = {r.file_path: r for r in crud.list_receipts(db)}
    file_receipts = []
    for f in files:
        r = receipts.get(f.file_path)
        file_receipts.append({
            "id": f.id,
            "file_name": f.file_name,
            "is_valid": f.is_valid,
            "is_processed": f.is_processed,
            "merchant_name": getattr(r, 'merchant_name', ''),
            "total_amount": getattr(r, 'total_amount', ''),
            "purchased_at": getattr(r, 'purchased_at', ''),
        })
    return templates.TemplateResponse("dashboard.html", {"request": request, "file_receipts": file_receipts, "info": info, "ocr_text": ocr_text})

@router.post("/upload")
def upload(request: Request, file: UploadFile = File(...), db: Session = Depends(get_db)):
    if not file.filename.lower().endswith('.pdf'):
        return templates.TemplateResponse("dashboard.html", {"request": request, "error": "Only PDF files are allowed."})
    file_path = os.path.join(config.UPLOAD_DIR, file.filename)
    with open(file_path, "wb") as f:
        f.write(file.file.read())
    db_file = crud.get_receipt_file_by_name(db, file.filename)
    if db_file:
        db_file = crud.update_receipt_file(db, db_file, file_path=file_path)
    else:
        db_file = crud.create_receipt_file(db, file.filename, file_path)
    return RedirectResponse(url="/", status_code=303)

@router.get("/process/{file_name}")
def process(file_name: str, request: Request, db: Session = Depends(get_db)):
    db_file = crud.get_receipt_file_by_name(db, file_name)
    if not db_file or not db_file.is_valid:
        return templates.TemplateResponse("dashboard.html", {"request": request, "error": "File not found or not valid."})
    text = ocr.extract_text_from_pdf(db_file.file_path)
    data = ocr.extract_receipt_data(text)
    if "error" in data:
        info = f"Error extracting data: {data['error']}"
    else:
        purchased_at = data.get("purchased_at")
        if purchased_at and isinstance(purchased_at, str):
            for fmt in ("%d/%m/%Y", "%m/%d/%Y", "%Y-%m-%d", "%d/%m/%y", "%m/%d/%y"):
                try:
                    data["purchased_at"] = datetime.strptime(purchased_at, fmt)
                    break
                except Exception:
                    continue
            else:
                data["purchased_at"] = None
        crud.create_receipt(db, file_path=db_file.file_path, **data)
        crud.update_receipt_file(db, db_file, is_processed=True)
        info = f"Extracted: Merchant: {data.get('merchant_name', '')}, Total: {data.get('total_amount', '')}, Date: {data.get('purchased_at', '')}"
    files = db.query(crud.models.ReceiptFile).all()
    receipts = {r.file_path: r for r in crud.list_receipts(db)}
    file_receipts = []
    for f in files:
        r = receipts.get(f.file_path)
        file_receipts.append({
            "id": f.id,
            "file_name": f.file_name,
            "is_valid": f.is_valid,
            "is_processed": f.is_processed,
            "merchant_name": getattr(r, 'merchant_name', ''),
            "total_amount": getattr(r, 'total_amount', ''),
            "purchased_at": getattr(r, 'purchased_at', ''),
        })
    return templates.TemplateResponse("dashboard.html", {"request": request, "file_receipts": file_receipts, "info": info})

@router.get("/validate/{file_name}")
def validate(file_name: str, request: Request, db: Session = Depends(get_db)):
    db_file = crud.get_receipt_file_by_name(db, file_name)
    if not db_file:
        return templates.TemplateResponse("dashboard.html", {"request": request, "error": "File not found."})
    is_valid, reason = utils.is_valid_pdf(db_file.file_path)
    crud.update_receipt_file(db, db_file, is_valid=is_valid, invalid_reason=reason)
    return RedirectResponse(url="/", status_code=303)

@router.get("/process_stream/{file_name}")
def process_stream(file_name: str, db: Session = Depends(get_db)):
    def event_stream():
        db_file = crud.get_receipt_file_by_name(db, file_name)
        if not db_file or not db_file.is_valid:
            yield "data: File not found or not valid.\n\n"
            return
        yield "data: Starting OCR extraction...\n\n"
        text = ocr.extract_text_from_pdf(db_file.file_path)
        yield "data: OCR extraction complete. Extracting fields with Gemini...\n\n"
        data = ocr.extract_receipt_data(text)
        if "error" in data:
            info = f"Error extracting data: {data['error']}"
        else:
            info = f"Extracted: Merchant: {data.get('merchant_name', '')}, Total: {data.get('total_amount', '')}, Date: {data.get('purchased_at', '')}"
        yield f"data: {info}\n\n"
        crud.create_receipt(db, file_path=db_file.file_path, **data)
        crud.update_receipt_file(db, db_file, is_processed=True)
        yield "data: Processing complete.\n\n"
    return StreamingResponse(event_stream(), media_type="text/event-stream")

@router.get("/ocr/{file_name}")
def ocr_action(file_name: str, request: Request, db: Session = Depends(get_db)):
    db_file = crud.get_receipt_file_by_name(db, file_name)
    if not db_file or not db_file.is_valid:
        return templates.TemplateResponse("dashboard.html", {"request": request, "error": "File not found or not valid."})
    text = ocr.extract_text_from_pdf(db_file.file_path)
    return dashboard(request, db, ocr_text=text)

@router.get("/delete_receipt_file/{file_id}")
def delete_receipt_file(file_id: int, request: Request, db: Session = Depends(get_db)):
    crud.delete_receipt_file(db, file_id)
    return RedirectResponse(url="/", status_code=303)

@router.get("/delete_receipt/{receipt_id}")
def delete_receipt(receipt_id: int, request: Request, db: Session = Depends(get_db)):
    crud.delete_receipt(db, receipt_id)
    return RedirectResponse(url="/", status_code=303)

@router.post("/delete_by_id")
def delete_by_id(
    request: Request,
    db: Session = Depends(get_db),
    file_id: str = Form(""),
    receipt_id: str = Form("")
):
    info = ""
    if file_id:
        try:
            file_id_int = int(file_id)
            if crud.delete_receipt_file(db, file_id_int):
                info += f"Deleted file entry with id {file_id_int}. "
            else:
                info += f"No file entry found with id {file_id_int}. "
        except ValueError:
            info += f"Invalid file ID '{file_id}'. "
    if receipt_id:
        try:
            receipt_id_int = int(receipt_id)
            if crud.delete_receipt(db, receipt_id_int):
                info += f"Deleted receipt entry with id {receipt_id_int}. "
            else:
                info += f"No receipt entry found with id {receipt_id_int}. "
        except ValueError:
            info += f"Invalid receipt ID '{receipt_id}'. "
    files = db.query(crud.models.ReceiptFile).all()
    receipts = {r.file_path: r for r in crud.list_receipts(db)}
    file_receipts = []
    for f in files:
        r = receipts.get(f.file_path)
        file_receipts.append({
            "id": f.id,
            "file_name": f.file_name,
            "is_valid": f.is_valid,
            "is_processed": f.is_processed,
            "merchant_name": getattr(r, 'merchant_name', ''),
            "total_amount": getattr(r, 'total_amount', ''),
            "purchased_at": getattr(r, 'purchased_at', ''),
        })
    return templates.TemplateResponse("dashboard.html", {"request": request, "file_receipts": file_receipts, "info": info}) 