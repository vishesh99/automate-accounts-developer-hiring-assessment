import google.generativeai as genai
import os
import json
from dotenv import load_dotenv
import re

load_dotenv()
# Set your API key (use environment variable for security)
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
genai.configure(api_key=GOOGLE_API_KEY)

def extract_receipt_data_with_gemini(text):
    prompt = (
        "Extract the following fields from this receipt text:\n"
        "- Merchant Name\n- Date of Purchase\n- Total Amount\n\n"
        "Return only a valid JSON object with keys: merchant_name, purchased_at, total_amount. Do not include any other text or explanation. \n\n"
        "Date can be in any format and the merchant name will be a company only,it should only be string with numbers and letters a-z nothing else\n\n"
        f"Receipt Text:\n{text}"
    )
    model = genai.GenerativeModel("gemini-2.0-flash")
    try:
        response = model.generate_content(prompt)
        print("Gemini raw response:", repr(response.text))
        cleaned = response.text.strip()
        # Remove triple backticks and optional 'json' label at the start
        cleaned = re.sub(r"^```json\s*|^```\s*|```$", "", cleaned, flags=re.IGNORECASE | re.MULTILINE).strip()
        if cleaned.startswith("{"):
            data = json.loads(cleaned)
        else:
            data = {
                "merchant_name": "",
                "total_amount": "",
                "purchased_at": "",
                "error": f"Invalid Gemini response: {response.text}"
            }
    except Exception as e:
        print("Gemini extraction error:", e)
        data = {
            "merchant_name": "",
            "total_amount": "",
            "purchased_at": "",
            "error": str(e)
        }
    return data
