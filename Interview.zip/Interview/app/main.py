import os
from fastapi import FastAPI, UploadFile, File, HTTPException, Depends
from fastapi.responses import JSONResponse
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from . import models, schemas, crud, ocr, utils, config
from sqlalchemy.exc import SQLAlchemyError
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from .dashboard import router as dashboard_router
from .deps import get_db, engine

app = FastAPI()

engine = create_engine(f"sqlite:///{config.DB_PATH}", connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
models.Base.metadata.create_all(bind=engine)

app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")
app.include_router(dashboard_router)

@app.post("/upload")
def upload_receipt(file: UploadFile = File(...), db: Session = Depends(get_db)):
    if not file.filename.lower().endswith('.pdf'):
        raise HTTPException(status_code=400, detail="Only PDF files are allowed.")
    file_path = os.path.join(config.UPLOAD_DIR, file.filename)
    with open(file_path, "wb") as f:
        f.write(file.file.read())
    db_file = crud.get_receipt_file_by_name(db, file.filename)
    if db_file:
        db_file = crud.update_receipt_file(db, db_file, file_path=file_path)
    else:
        db_file = crud.create_receipt_file(db, file.filename, file_path)
    return {"id": db_file.id, "file_name": db_file.file_name, "file_path": db_file.file_path}

@app.post("/validate")
def validate_receipt(file_name: str, db: Session = Depends(get_db)):
    db_file = crud.get_receipt_file_by_name(db, file_name)
    if not db_file:
        raise HTTPException(status_code=404, detail="File not found.")
    is_valid, reason = utils.is_valid_pdf(db_file.file_path)
    db_file = crud.update_receipt_file(db, db_file, is_valid=is_valid, invalid_reason=reason)
    return {"id": db_file.id, "is_valid": db_file.is_valid, "invalid_reason": db_file.invalid_reason}

@app.post("/process")
def process_receipt(file_name: str, db: Session = Depends(get_db)):
    db_file = crud.get_receipt_file_by_name(db, file_name)
    if not db_file or not db_file.is_valid:
        raise HTTPException(status_code=400, detail="File not found or not valid.")
    try:
        text = ocr.extract_text_from_pdf(db_file.file_path)
        data = ocr.extract_receipt_data(text)
        receipt = crud.create_receipt(db, file_path=db_file.file_path, **data)
        crud.update_receipt_file(db, db_file, is_processed=True)
        return {"receipt_id": receipt.id, **data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/receipts")
def list_receipts(db: Session = Depends(get_db)):
    receipts = crud.list_receipts(db)
    return receipts

@app.get("/receipts/{receipt_id}")
def get_receipt(receipt_id: int, db: Session = Depends(get_db)):
    receipt = crud.get_receipt(db, receipt_id)
    if not receipt:
        raise HTTPException(status_code=404, detail="Receipt not found.")
    return receipt 