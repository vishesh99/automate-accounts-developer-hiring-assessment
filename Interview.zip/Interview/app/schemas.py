from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class ReceiptFileBase(BaseModel):
    file_name: str
    file_path: str
    is_valid: bool
    invalid_reason: Optional[str] = None
    is_processed: bool
    created_at: datetime
    updated_at: Optional[datetime] = None

class ReceiptFileCreate(BaseModel):
    file_name: str
    file_path: str

class ReceiptBase(BaseModel):
    purchased_at: Optional[datetime] = None
    merchant_name: Optional[str] = None
    total_amount: Optional[float] = None
    file_path: str
    created_at: datetime
    updated_at: Optional[datetime] = None

class ReceiptCreate(BaseModel):
    purchased_at: Optional[datetime] = None
    merchant_name: Optional[str] = None
    total_amount: Optional[float] = None
    file_path: str 