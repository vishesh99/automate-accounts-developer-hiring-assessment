from PyPDF2 import PdfReader

def is_valid_pdf(file_path):
    try:
        reader = PdfReader(file_path)
        # Try to read the first page
        _ = reader.pages[0]
        return True, None
    except Exception as e:
        return False, str(e) 